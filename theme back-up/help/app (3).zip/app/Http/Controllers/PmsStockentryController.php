<?php

namespace App\Http\Controllers;

use App\Models\Pms_stockentry;
use Illuminate\Http\Request;

class PmsStockentryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Pms_stockentry  $pms_stockentry
     * @return \Illuminate\Http\Response
     */
    public function show(Pms_stockentry $pms_stockentry)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Pms_stockentry  $pms_stockentry
     * @return \Illuminate\Http\Response
     */
    public function edit(Pms_stockentry $pms_stockentry)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Pms_stockentry  $pms_stockentry
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pms_stockentry $pms_stockentry)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Pms_stockentry  $pms_stockentry
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pms_stockentry $pms_stockentry)
    {
        //
    }
}
