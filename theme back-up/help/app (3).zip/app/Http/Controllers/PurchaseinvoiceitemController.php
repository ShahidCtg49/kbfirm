<?php

namespace App\Http\Controllers;

use App\Models\Purchaseinvoiceitem;
use Illuminate\Http\Request;

class PurchaseinvoiceitemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Purchaseinvoiceitem  $purchaseinvoiceitem
     * @return \Illuminate\Http\Response
     */
    public function show(Purchaseinvoiceitem $purchaseinvoiceitem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Purchaseinvoiceitem  $purchaseinvoiceitem
     * @return \Illuminate\Http\Response
     */
    public function edit(Purchaseinvoiceitem $purchaseinvoiceitem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Purchaseinvoiceitem  $purchaseinvoiceitem
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Purchaseinvoiceitem $purchaseinvoiceitem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Purchaseinvoiceitem  $purchaseinvoiceitem
     * @return \Illuminate\Http\Response
     */
    public function destroy(Purchaseinvoiceitem $purchaseinvoiceitem)
    {
        //
    }
}
